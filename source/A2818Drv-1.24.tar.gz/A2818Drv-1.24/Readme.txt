
        ----------------------------------------------------------------------

                    --- CAEN SpA - Computing Systems Division --- 

        ----------------------------------------------------------------------
        
        A2818 Driver Readme file
        
        ----------------------------------------------------------------------


        May 2022


 The complete documentation can be found in the User's Manual on CAEN's web
 site at: http://www.caen.it.


 Content
 -------

 Readme.txt       : This file.

 ReleaseNotes.txt : Release Notes of the last software release.

 a2818.c          : The source file of the driver

 a2818.h          : The header file of the driver

 Makefile         : The Makefile to compile the driver

 a2818_load.2.x   : The scripts to load the driver


 System Requirements
 -------------------

 - CAEN A2818 PCI CARD
 - Linux kernel with gnu C/C++ compiler
 
 -------------------------------------------------------------------------------------------------------------------

 					N.B.
 CAEN provides Linux drivers for its products as source code (open source). For Linux kernels requiring the
 digital signature for driver installation, the User must compile the driver by signing it with his own digital
 certificate or disable the demand for the digital signature in the kernel.
 If an unsigned driver is loaded on a kernel that requires a signature, the message "ERROR: unable to insert \
 'DriverName \': Operation not allowed" will appear.

--------------------------------------------------------------------------------------------------------------------

 Installation notes
 ------------------

  To install the A2818 device driver:

  - Excecute: cp ./Makefile.2.4 Makefile (for 2.4 kernel) cp ./Makefile.2.6-3.x Makefile (for >=2.6 kernel)

  - Execute: make

  - Execute: sh a2818_load.2.4 (for 2.4 kernel) 
             or sh a2818_load (for >= 2.6 kernel)
