void sca(void){
  //read_sscaler(SCR1P,SCR1L,0,SCR1N);            // Read Scaler
  //read_sscaler(SCR2P,SCR2L,0,SCR2N);            // Read Scaler
  //control_mod(0,SCR1N,0,9);              // Clear Scaler
  //control_mod(0,SCR2N,0,9);              // Clear Scaler
}
