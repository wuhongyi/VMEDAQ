void stop(void){
  rpv130_output(RPV130ADDR, OPBUFFCL);
}
