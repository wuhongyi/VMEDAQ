#include <stdio.h>
#include <fcntl.h>
#include "command.h"

extern void hstdef_();
extern void event1_(unsigned short *);
extern void hstend_();

int main(int argc,char *argv[]){
  int fd,pos;
  unsigned short int buffer[MAX_BUF];
  unsigned short int event[MAX_BUF];
  int commentlen;
  if (argc <=1 ){
    printf("Usage: offline rawdata\n");
    exit(1);
  }
  hstdef_();
  if ((fd = open(argv[1],O_RDONLY)) < 0) exit(1);
  read(fd,(char *)buffer,sizeof(short));
  commentlen = (int)buffer[0];
  read(fd,(char *)buffer,commentlen);
  printf("comment:%s\n",buffer);
  pos = 0;
  while(read(fd,&event,sizeof(short))> 0){
    if (event[0] != DELIM) {
      read(fd,&(event[1]),(event[0]-1)*sizeof(short));
      event1_(event);
    }
  }
  hstend_();
  exit(0);
}
