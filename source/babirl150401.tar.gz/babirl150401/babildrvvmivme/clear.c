void clear(void){
  //madc32_clear_map(MADCMAPN);
  //madc32_start_acq_map(MADCMAPN);

  //v1190_map_intlevel(INTLEVEL, TDC1MAPN); // Enable Interrupt
  //madc32_irq_level(MADCMAPN, INTLEVEL);

  //vlupodm_pulse_map(LUPOMAPN, OPBUSYCL);
  //vlupodm_enable_interrupt_map(LUPOMAPN);
  vlupodm_clear_map(LUPOMAPN);
}
