void map(void){

  univ_init_window(LUPOADDR, REGSIZE, A32, LUPOMAPN);
  //univ_init_window(TDC1ADDR, REGSIZE, A32, TDC1MAPN);
  //univ_init_window(MADCADDR, 0x8000, A32, MADCMAPN);
  //univ_init_dma(TDC1ADDR, DMASIZE, TDC1MAPN);
}


void startup(void){
  short val;
  /* Startup Function */

  //v1190_map_intlevel(0, TDC1MAPN); // Disable Interrupt
  val = 0x00;  // 0x03=Enable Trig. and VETO
  vlupodm_trgact_map(LUPOMAPN, val);
  vme_define_intlevel(INTLEVEL);

  //scrinit();
  //madc32_resol_8khires(MADCMAPN);

  // Output Configuration
  val = 0x04;  // 1=Output Reg.
  vlupodm_outconf0_map(LUPOMAPN, val);
  val = 0x20;  // 1=Output Reg.
  vlupodm_outconf1_map(LUPOMAPN, val);
  val = 0x01;  // 1=Output Reg.
  vlupodm_outconf2_map(LUPOMAPN, val);
  val = 0x08;  // 1=Output Reg.
  vlupodm_outconf3_map(LUPOMAPN, val);
  //v1190_map_clear(TDC1MAPN);
  vlupodm_clearall_map(LUPOMAPN);

  //madc32_clear_map(MADCMAPN);
  //madc32_start_acq_map(MADCMAPN);

  //madc32_irq_level(MADCMAPN, INTLEVEL);
  vlupodm_intdelay_map(LUPOMAPN, 2000);

  vlupodm_enable_interrupt_map(LUPOMAPN);
  val = 0x03;  // 0x03=Enable Trig. and VETO
  vlupodm_trgact_map(LUPOMAPN, val);
}
