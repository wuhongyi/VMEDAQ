#define SEGIDGEN(device,focal,detector,module) ((((device<<6 | focal) << 6) | detector)<<8 | module)    

#include "segidlist.h"
#define EFN 21

#define BBRL
//#define MAXBUFF  16000
#define MAXBUFF  8192
//#define MAXBUFF  2000
#define DBUFF

#define VME
#define VMEINT
#define INTLEVEL 5
#define INTVEC   0
#define UNIV

#define DMASIZE  16384
#define REGSIZE  0x2000

#define A32 0x09
#define A16 0x29

#define LUPOADDR 0x30000000
#define LUPOMAPN 1

//#define MADCADDR 0x44440000
//#define MADCMAPN 2

#define SCRID     21
#define LUPOSCRID 11
