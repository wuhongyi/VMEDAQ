void sca(void){

  //init_ncscaler(SCRID);
  //sis3800_ridf_ncscaler_map(SCRMAPN);
  //end_ncscaler();

  init_ncscaler(LUPOSCRID);
  vlupodm_scrungated_map(LUPOMAPN);
  vlupodm_scrgated_map(LUPOMAPN);
  vlupodm_scrclk1k_map(LUPOMAPN);
  vlupodm_scrclk10k_map(LUPOMAPN);
  vlupodm_scrclk10m_map(LUPOMAPN);
  vlupodm_scrscr0_map(LUPOMAPN);
  vlupodm_scrscr1_map(LUPOMAPN);
  vlupodm_scrscr2_map(LUPOMAPN);
  vlupodm_scrscr3_map(LUPOMAPN);
  vlupodm_scrdummy();
  vlupodm_scrdummy();
  vlupodm_scrdummy();
  end_ncscaler();

}

void scrinit(void){
  /*
  sis3800_initialize_map(SCRMAPN);
  sis3800_inputmode_map(SCRMAPN, SIS3800_MODE1);
  sis3800_clear_all_map(SCRMAPN);
  */
}

