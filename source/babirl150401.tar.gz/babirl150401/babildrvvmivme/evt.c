void evt(void){
  /* Event */
  //vlupodm_disable_interrupt_map(LUPOMAPN);
  //madc32_irq_level(MADCMAPN, 0);

  init_event();

  init_segment(SEGIDGEN(DALI, F8, B2SCALER, C24));
  vlupodm_segscr1_map(LUPOMAPN);
  vlupodm_segclk10k_map(LUPOMAPN);
  end_segment(); 

  init_segment(SEGIDGEN(DALI, F8, DALIA, MADC32));
  //madc32_segdata_map(MADCMAPN);
  end_segment();

}

