void unmap(void){
  //univ_end_window(MADCMAPN);
  univ_end_window(LUPOMAPN);
}


void stop(void){
  //v1190_map_intlevel(0, TDC1MAPN); // Disable Interrupt
  //madc32_irq_level(MADCMAPN, 0);
  vlupodm_disable_interrupt_map(LUPOMAPN);
  vlupodm_trgact_map(LUPOMAPN, 0);
  vlupodm_clear_map(LUPOMAPN);
}

