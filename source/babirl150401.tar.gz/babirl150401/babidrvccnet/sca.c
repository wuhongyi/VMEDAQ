void sca(void){
  init_ncscaler(EFN);
  usr_ccnet_scrdata_dma24();
  end_ncscaler();
}
