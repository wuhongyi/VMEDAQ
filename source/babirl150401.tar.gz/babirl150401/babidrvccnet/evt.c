void evt(void){
  /* Don't modify this file. */
  /* Please modify ccnetsegment.c */

  check_lam();

  /* Initialize event */
  init_event();

  /* Read and store ccnet data */
  ccnet_recseg();

  
}
