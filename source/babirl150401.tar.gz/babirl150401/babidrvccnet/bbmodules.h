#include "segidlist.h"

#define EFN     23
#define MAXBUFF 3500
#define CAMAC
#define CCNET

#define DBUFF

/* Dummy LAMN */
#define LAMN 0

#define CMDLEN 300


#define USR_CMDLEN 100
#define CLKSCR  10
#define SCRLEN 12
