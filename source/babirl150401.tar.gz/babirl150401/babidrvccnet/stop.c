void stop(void){
  /* Clear modules */
  //control_mod(0, N, 0, 9);      // Clear command
  //write_data(0, N, 0, 17, VAL); // via out put register
}
