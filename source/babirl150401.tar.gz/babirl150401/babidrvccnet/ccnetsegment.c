void ccnetsegment(void){
  /* Event */
  /* Scaler */
  init_segment(SEGIDGEN(BIGRIPS,F7,SCALER,C24));
  read_segndata24(2,0,10,0,0);
  end_segment();

  /* F7 */
  /* TDC */
  init_segment(SEGIDGEN(BIGRIPS,F7,PPACT,C16));
  read_segndata(4,0,6,0,0);
  read_segndata(16,0,7,0,0);
  end_segment();
  
  control_mod(0,6,0,9);
  control_mod(0,7,0,9);
}
