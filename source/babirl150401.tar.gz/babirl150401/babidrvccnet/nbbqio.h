/* nbbqio.h */

#define NBBQ_STOP 2
#define NBBQ_EI   3
