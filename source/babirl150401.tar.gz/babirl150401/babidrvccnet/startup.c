void startup(void){
  int i, val=0;

  /* Startup Function */
  ccnet_crate_reset();
  check_lam();

  /* Dummy LAM definition */
  crate_define_lam(LAMN);

  /* Create ccnet command frame */
  ccnetstartup();

  /* Create user command frame */
  usr_ccnet_gen_init(USR_CMDLEN);
  for(i=0;i<SCRLEN;i++){
    usr_ccnet_gen_cc(CLKSCR, i, 0, val);
  }

  /* Clear modules */
  //control_mod(0, N, 0, 9);      // Clear command
  //write_data(0, N, 0, 17, VAL); // via out put register

  control_mod(0, 6, 0, 9);
  control_mod(0, 7, 0, 9);
  control_mod(0, 10, 0, 9);


  /* Set trigger mode */
  ccnet_trig();                   // Interrupt by CC/NET front panel
  ccnet_pulsemode();              // Define pulse mode
  ccnet_pulse();                  // Output pulse from CC/NET front panel
}
