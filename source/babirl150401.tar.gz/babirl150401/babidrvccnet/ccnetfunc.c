/* Created by mkccnetsegment */

void ccnetstartup(void){
  int i, val=0;

  ccnet_gen_init(CMDLEN);
  for(i=0;i<2;i++){
    ccnet_gen_cc(10, i+0, 0, val);
  }
  for(i=0;i<4;i++){
    ccnet_gen_cc(6, i+0, 0, val);
  }
  for(i=0;i<16;i++){
    ccnet_gen_cc(7, i+0, 0, val);
  }
  for(i=0;i<4;i++){
    ccnet_gen_cc(2, i+0, 2, val);
  }
  for(i=0;i<16;i++){
    ccnet_gen_cc(4, i+0, 2, val);
  }
  ccnet_gen_cc(9, 0, 0, val);
  ccnet_gen_cc(9, 5, 0, val);
  for(i=0;i<2;i++){
    ccnet_gen_cc(2, i+4, 2, val);
  }
  ccnet_gen_cc(9, 2, 0, val);
  ccnet_gen_cc(9, 7, 0, val);
  ccnet_gen_cc(9, 3, 0, val);
  ccnet_gen_cc(9, 4, 0, val);
  ccnet_gen_cc(1, 0, 9, val);
  ccnet_gen_cc(6, 0, 9, val);
  ccnet_gen_cc(7, 0, 9, val);
  ccnet_gen_cc(9, 0, 9, val);

  segcmdlen = 30;
  segcmd[0] = 0x1001ff01;
  segcmd[1] = 0x30000002;
  segcmd[2] = 0x40000000;
  segcmd[3] = 0x1001c100;
  segcmd[4] = 0x20000004;
  segcmd[5] = 0x20000010;
  segcmd[6] = 0x40000000;
  segcmd[7] = 0x1001c000;
  segcmd[8] = 0x20000004;
  segcmd[9] = 0x20000010;
  segcmd[10] = 0x40000000;
  segcmd[11] = 0x1001ce00;
  segcmd[12] = 0x20000001;
  segcmd[13] = 0x20000001;
  segcmd[14] = 0x40000000;
  segcmd[15] = 0x1001c200;
  segcmd[16] = 0x20000002;
  segcmd[17] = 0x40000000;
  segcmd[18] = 0x1001cd00;
  segcmd[19] = 0x20000001;
  segcmd[20] = 0x20000001;
  segcmd[21] = 0x40000000;
  segcmd[22] = 0x1000cd00;
  segcmd[23] = 0x20000001;
  segcmd[24] = 0x20000001;
  segcmd[25] = 0x40000000;
  segcmd[26] = 0x50000001;
  segcmd[27] = 0x50000001;
  segcmd[28] = 0x50000001;
  segcmd[29] = 0x50000001;
}
