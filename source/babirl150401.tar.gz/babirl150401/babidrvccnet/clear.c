void clear(void){
  ccnet_pulse();    // Output busy clear pulse
}
