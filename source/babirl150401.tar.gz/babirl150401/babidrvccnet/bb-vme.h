extern void set_amsr(unsigned char am);
extern void vread16(unsigned long addr,short *data);
extern void vread32(unsigned long addr,long *data);
extern void vwrite16(unsigned long addr,short *data);
extern void vwrite32(unsigned long addr,long *data);
extern int get_irq(void);
extern void vme_enable_interrupt(void);
extern void vme_disable_interrupt(void);
extern void vme_define_intlevel(int level);
extern int vme_check_interrupt(void);
extern int vme_read_intvector(void);


extern void set_amsr_i(unsigned char am, int dn);
extern void vread16_i(unsigned long addr,short *data, int dn);
extern void vread32_i(unsigned long addr,long *data, int dn);
extern void vwrite16_i(unsigned long addr,short *data, int dn);
extern void vwrite32_i(unsigned long addr,long *data, int dn);

extern int vme_dma_vread32_start(unsigned long addr,int size);
extern int vme_dma_vread32_store(char *data, int size);
extern int vme_dma_vread32_start_i(unsigned long addr,int size, int dn);
extern int vme_dma_vread32_store_i(char *data, int size, int dn);
