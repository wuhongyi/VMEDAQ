#include <stdio.h>

int main(int argc, char *argv[]){
  int i;

  while(1){
    i++;
  }

  return 0;
}
