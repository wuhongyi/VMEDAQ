<?php
class Cbbhtml{
  function contenttype(){
    header("Content-Type: text/html; charset=utf-8");
  }

  function html($n = NULL){
    if(!$n){
      echo "<html>\n";
    }else{
      echo "</html>\n";
    }
  }

  function head($n = NULL){
    if(!$n){
      echo "<head>\n";
    }else{
      echo "</head>\n";
    }
  }

  function body($n = NULL){
    if(!$n){
      echo "<body>\n";
    }else{
      echo "</body>\n";
    }
  }

  function title($title = "Title"){
    echo "<title>".$title."</title>\n";
  }
  
  function heading($lv = "1", $val = "H1"){
    echo "<h".$lv.">".$val."</h".$lv.">\n";
  }

  function hr($wid=NULL){
    echo "<hr";
    if($wid){
      echo " width=".$wid;
    }
    echo ">\n";
  }

  function script($file){
    echo "<script src='".$file."' type='text/javascript'></script>\n";
  }

  function std_html_header($title){
    $this->contenttype();
    $this->html(0);
    $this->head(0);
    $this->title($title);
    $this->head(1);
    $this->body(0);
    echo "<p>\n";
  }

  function std_html_ender(){
    echo "</p>\n";
    $this->body(1);
    $this->html(1);
  }

  // End of class
  }

?>
