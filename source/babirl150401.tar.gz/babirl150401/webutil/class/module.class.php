<?php

class CModule {
  public $name = 'Generic';

  function __construct($name){
    if(strlen($name)){
      $this->name = $name;
    }
  }

}


class CCAMAC extends CModule {
  public $c=-1,$n=-1;

  function setCN($c, $n){
    $this->c = $c;
    $this->n = $n;
  }
}

class CVME extends CModule {
  public $base=-1;

  function setBaseAddress($base){
    $this->base = $base;
  }
}


class CChannelData {
  public $ch = -1;
  public $val = -1;
  public $edge = -1;

  function __construct($ch){
    $this->ch = $ch;
  }

  function setVal($val){
    $this->val = $val;
  }

  function getChannel(){
    return $this->ch;
  }

  function getVal(){
    return $this->val;
  }

  function setEdge($edge){
    $this->edge = $edge;
  }

  function getEdge(){
    return $this->edge;
  }
}

class CModuleData {
  public $geo = -1;
  public $ch = array();

  function __construct($geo){
    $this->geo = $geo;
  }

  function addChannel($ch){
    $cch = new CChannelData($ch);
    array_push($this->ch, $cch);
  }

  function getGeo(){
    return $this->geo;
  }

  function getCh($ch){
    foreach ($this->ch as $c){
      if($c->getChannel() == $ch){
	return $c;
      }
    }
    return NULL;
  }

  function getChEdge($ch, $edge){
    foreach ($this->ch as $c){
      if($c->getChannel() == $ch && $c->getEdge() == $edge){
	return $c;
      }
    }
    return NULL;
  }

  function getChannelEdgeVal($ch, $edge){
    foreach($this->ch as $c){
      if($c->getChannel() == $ch && $c->getEdge() == $edge){
	return $c->getVal();
      }
      return -1;
    }
  }

  function setChannelVal($ch, $val){
    foreach ($this->ch as $c){
      if($c->getChannel() == $ch){
	$c->setVal($val);
	return;
      }
    }
    $this->addChannel($ch);
    $c = end($this->ch);
    $c->setVal($val);
  }

  function setChannelEdgeVal($ch, $edge, $val){
    foreach ($this->ch as $c){
      if($c->getChannel() == $ch && $c->getEdge() == $edge){
	$c->setVal($val);
	$c->setEdge($edge);
	return;
      }
    }
    $this->addChannel($ch);
    $c = end($this->ch);
    $c->setVal($val);
    $c->setEdge($edge);
  }

}


?>
