<?php

require_once('module.class.php');
require_once('Generic_Scaler32Bit.class.php');

class SIS_3820 extends Generic_Scaler32Bit {
  // inherit all
}


?>
