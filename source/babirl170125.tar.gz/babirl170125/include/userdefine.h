/* include/userdefine.h */

//#define BABIRLDIR "/home/daq/daq/babirl"
//#define PIDDIR    "/home/daq/daq/babirl/run"
