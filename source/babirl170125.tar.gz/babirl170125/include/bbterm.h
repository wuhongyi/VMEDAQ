#ifndef BBTERM_H
#define BBTERM_H
#include <ncurses.h>
#include <term.h>
int get_terminfo(int *row, int *col);
#endif
