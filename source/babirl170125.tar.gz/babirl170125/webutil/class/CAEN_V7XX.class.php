<?php

require_once('module.class.php');

class CAEN_V7XX {
  public $module = array();

  const HDMASK   = 0x06000000;
  const HDVALID  = 0x06000000;
  const HDHEADER = 0x02000000;
  const HDEOB    = 0x04000000;
  const HDDATA   = 0x00000000;
  const GEOMASK  = 0xf8000000;
  const GEOSFT   = 27;
  const CNTMASK  = 0x00003f00;
  const CNTSFT   = 8;
  const CHMASK   = 0x001f0000;
  const CHSFT    = 16;
  const ADCMASK  = 0x00001fff;
  const ADCSFT   = 0;

  function decode($buff){
    $flag = 0;
    $list = unpack("I*", $buff);
    $cnt = count($list);
    for($i=1;$i<=$cnt;$i++){
      $hd = $list[$i] & self::HDMASK;
      if($hd == self::HDVALID){
	$flag = 0;
	continue;
      }else if($hd == self::HDHEADER && !$flag){
	$geo = ($list[$i] & self::GEOMASK) >> self::GEOSFT;
	$mod = new CModuleData($geo);
	array_push($this->module, $mod);
	$flag = 1;
      }else if($hd == self::HDDATA && $flag){
	$ch =  ($list[$i] & self::CHMASK) >> self::CHSFT;
	$val = ($list[$i] & self::ADCMASK) >> self::ADCSFT;
	$mod->setChannelVal($ch, $val);
      }else if($hd == self::HDEOB && $flag){
	$flag = 0;
	continue;
      }
    }
  }

  function show_decode(){
    echo "<pre>";
    foreach ($this->module as $mod){
      printf("geo=%2d ",$mod->getGeo());
      $lines = 0;
      for($i=0;$i<32;$i++){
	if($ch = $mod->getCh($i)){
	  printf("%2d:%4d ",$i, $ch->getVal());
	  $lines++;
	}
	if($lines >= 8){
	  $lines = 0;
	  echo "\n       ";
	}
      }
      echo "\n";
    }
    echo "</pre>";
  }
}


?>
