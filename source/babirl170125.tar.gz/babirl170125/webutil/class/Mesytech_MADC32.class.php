<?php

require_once('module.class.php');

class Mesytech_MADC32 {
  public $module = array();

  const MSK      = 0xc0000000;
  const MSKSFT   = 30;
  const HEADER   = 0x01;
  const DATA     = 0x00;
  const ENDER    = 0x11;
  const GEOMSK   = 0x00ff0000;
  const GEOSFT   = 16;
  const CHMSK    = 0x001f0000;
  const CHSFT    = 16;
  const ADCMSK   = 0x00007fff;
  const ADCSFT   = 0;

  function decode($buff){
    $flag = 0;
    $list = unpack("I*", $buff);
    $cnt = count($list);
    for($i=1;$i<=$cnt;$i++){
      $msk = ($list[$i] & self::MSK) >> self::MSKSFT;
      if($msk == self::ENDER){
	$flag = 0;
	continue;
      }else if($msk == self::HEADER && !$flag){
	$geo = ($list[$i] & self::GEOMSK) >> self::GEOSFT;
	$mod = new CModuleData($geo);
	array_push($this->module, $mod);
	$flag = 1;
	continue;
      }else if($msk == self::DATA && $flag){
	$ch =  ($list[$i] & self::CHMSK) >> self::CHSFT;
	$val = ($list[$i] & self::ADCMSK) >> self::ADCSFT;
	$mod->setChannelVal($ch, $val);
	continue;
      }else{
	$flag = 0;
	continue;
      }
    }
  }

  function show_decode(){
    echo "<pre>";
    foreach ($this->module as $mod){
      printf("geo=%2d ",$mod->getGeo());
      $lines = 0;
      for($i=0;$i<32;$i++){
	if($ch = $mod->getCh($i)){
	  printf("%2d:%4d ",$i, $ch->getVal());
	  $lines++;
	}
	if($lines >= 8){
	  $lines = 0;
	  echo "\n       ";
	}
      }
      echo "\n";
    }
    echo "</pre>";
  }
}


?>
