<html>
<head>
<title>babirl XML DAQ Status Monitor</title>
</head>
<body>
<h1>babirl XML DAQ Status Monitor</h1>

<a href="./index.php">Back to index page</a>

<p><?php
require "babilib.php";
require "babixlib.php";

$arserver = array();

if(!($hostlist = simplexml_load_file("./dat/hostlist.xml"))){
  echo "no hostlist!!<br>";
  echo "<a href='index.php'>Go to the index page</a>";
  die();
 }

//echo $hostlist->asXML();
foreach($hostlist->host as $node){
  if($node->babild){
    array_push($arserver, $node->name);
    $on["$node->name"] = 0;
  }
}

echo date("Y/m/d H:i:s");

echo "<form action='babixst.php' method='post'>";

if(isset($_POST)){
  $post = $_POST;
  $postflag = 1;
  if(!count($post)) $postflag = 0;
}else{
  $postflag = 0;
}

$tmpfile = 'dat/babixst.tmp';

$opt = '';
$efn = '';
$onn = 0;

if($postflag){
  while(list($key, $val) = each($post)){
    foreach($arserver as $name){
      if(!strcmp($key, $name)){
	$on["$name"] = 1;
	$onn++;
      }
    }
  }

  if($onn){
    $fd = fopen($tmpfile, 'w');
    foreach($arserver as $name){
      if($on["$name"]){
	fprintf($fd, "%s\n", $name);
      }
    }
    fclose($fd);
  }else{
    if(file_exists($tmpfile)){
      unlink($tmpfile);
    }
  }
}else{
  if(file_exists($tmpfile)){
    if(($fd = fopen($tmpfile, 'r'))){
      while(!feof($fd)){
	$line = fgets($fd);
	$nline = rtrim($line, "\n");
	foreach($arserver as $name){
	  if(!strcmp($nline, $name)){
	    $on["$name"] = 1;
	  }
	}
      }
    }
  }else{
    // noop
  }
}

echo "<hr width=500 align=left>\n";
$cnt = 0;
foreach($arserver as $name){
  if($on["$name"]){
    echo "<input type='checkbox' value='ON' name='$name' checked>$name</input>\n";
  }else{
    echo "<input type='checkbox' value='ON' name='$name'>$name</input>\n";
  }
  $cnt ++;
  if($cnt == 10){
    print "<br>\n";
    $cnt = 0;
  }
}

echo "<hr width=500 align=left>\n";
echo "<button type='submit' name='refresh'>Refresh</button> \n ";

$dom = new DomDocument('1.0');
$xcom = $dom->appendChild($dom->createElement('babildxcom'));
$xcom->appendChild($dom->createElement('getdaqinfo'));
$dom->formatOutput = true;
$xml = $dom->saveXML();

$domr = new DomDocument('1.0');
$xcomr = $domr->appendChild($domr->createElement('babildxcom'));
$xcomr->appendChild($domr->createElement('getruninfo'));
$domr->formatOutput = true;
$xmlr = $domr->saveXML();

foreach($arserver as $name){
  if($on["$name"]){
    $server = $name;
    
    //echo "hoge $server";
    echo "<hr width=500 align=left>\n";
    echo "<h2>Server = $server</h2>\n";

    $rxml = babildxcom($server, $xml);
    $rdom = simplexml_load_string($rxml);

    printxdaqinfo($rdom);
    printxeflist($rdom);
    printxhdlist($rdom);
    //echo $rxml;

    $rxmlr = babildxcom($server, $xmlr);
    $rdomr = simplexml_load_string($rxmlr);
    printxruninfo($rdomr);

  }
}

echo "<hr width=500 align=left>\n";
echo "<button type='submit' name='refresh'>Refresh</button>\n";
echo "</form>";    


?></p>


</body>
</html>
