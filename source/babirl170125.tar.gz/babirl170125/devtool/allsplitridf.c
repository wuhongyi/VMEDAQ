/* devtool/splitridf.c
 * 
 * last modified : 08/03/19 14:27:02 
 * 
 * Hidetada Baba (RIKEN)
 * baba@ribf.riken.jp
 *
 * RIDF splitter
 * Event assembly data to event fragment data 
 *
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/types.h>

#include <bi-config.h>
#include <bi-common.h>
#include <ridf.h>

#define MAXSEGID  200

int hds, evthds, seghds;
unsigned short ibuff[EB_EFBLOCK_SIZE];
static FILE *ifd;
static FILE *ofd[MAXSEGID];
int seglist[MAXSEGID];
int segn = 0;
char name[128] = {0};

int findsegn(int segid){
  int i;
  char ofile[128] = {0};
  //struct stbsegid bsid;

  for(i=0; i<MAXSEGID; i++){
    if(seglist[i] == segid) return i;
  }

  seglist[segn] = segid;

  mkdir(name, 0755);
  sprintf(ofile, "%s/%08x.segment", name, segid);
  ofd[segn] = fopen(ofile, "w");
  if(!ofd[segn]){
    printf("Cannot open output file %s\n", ofile);
    exit(1);
  }else{
    //memcpy((char *)&bsid, (char *)&segid, sizeof(segid));
    //printf("Write Segid(%08x) to %s (segn=%d)\n", segid, ofile, segn);
    //printf("Rev %d / Dev %d / FP  %d / Det %d / Mod %d\n\n",
    //bsid.revision, bsid.device, bsid.focal,
    //bsid.detector, bsid.module);
    //printf("%s ", ofile);
  }

  segn++;
  return segn-1;
}

int main(int argc, char *argv[]){
  RIDFHD hd;
  RIDFRHD rhd;
  RIDFHDEVT evthd;
  RIDFHDSEG seghd;
  int evtn, i, n;
  char *idx;
  unsigned long long int ts;
  unsigned int segid, segdatas;

  if(argc < 2){
    printf("allsplitridf INFILE\n");
    exit(0);
  }

  // Initialize
  for(i=0;i<MAXSEGID;i++){
    seglist[i] = 0;
    ofd[i] = 0;
  }

  // Input File
  if((ifd = fopen(argv[1], "r")) == NULL){
    printf("Can't open input file %s\n", argv[2]);
    exit(1);
  }

  // make output directory
  strcpy(name, argv[1]);
  idx = strstr(name, ".ridf");
  if(idx){
    *idx = 0;
  }else{
    printf("Invalid input file %s\n", name);
    fclose(ifd);
    exit(0);
  }
  
  printf("\n");

  memset(ibuff, 0, sizeof(ibuff));
  hds = sizeof(hd)/WORDSIZE;
  evthds = sizeof(evthd)/WORDSIZE;
  seghds = sizeof(seghd)/WORDSIZE;

  while(fread((char *)&hd, sizeof(hd), 1, ifd) == 1){
    rhd = ridf_dechd(hd);
    switch(rhd.classid){
    case RIDF_EF_BLOCK:
    case RIDF_EA_BLOCK:
    case RIDF_EAEF_BLOCK:
      break;
    case RIDF_EVENT:
      fread((char *)&evtn, sizeof(evtn), 1, ifd);
      break;
    case RIDF_EVENT_TS:
      fread((char *)&evtn, sizeof(evtn), 1, ifd);
      fread((char *)&ts, sizeof(ts), 1, ifd);
      break;
    case RIDF_SEGMENT:
      fread((char *)&segid, sizeof(segid), 1, ifd);

      n = findsegn(segid);

      segdatas = rhd.blksize-(sizeof(hd)+sizeof(segid))/WORDSIZE;
      fread((char *)ibuff, 2, segdatas, ifd);

      fwrite((char *)&hd, sizeof(hd), 1, ofd[n]);
      fwrite((char *)&segid, sizeof(segid), 1, ofd[n]);
      fwrite((char *)ibuff, 2, segdatas, ofd[n]);

      break;
    default:
      segdatas = rhd.blksize-sizeof(hd)/WORDSIZE;
      fread((char *)ibuff, 2, segdatas, ifd);
      break;
    }
  }

  printf("\n Last event number = %d\n", evtn);

  for(i=0;i<MAXSEGID;i++){
    if(ofd[i]){
      fclose(ofd[i]);
    }
  }

  fclose(ifd);

  return 0;
}
