#define EFN     10
#define MAXBUFF 3000
#define VME
#define VMEINT
//#define SBS620
#define V2718

#define DBUFF

#define INTLEVEL 1

#define ADCADDR 0x11110000

#define USE_CAEN
