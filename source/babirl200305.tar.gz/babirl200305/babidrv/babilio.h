/* nbbqio.h */

#define BABIL_STOP  2
#define BABIL_STOPB 9
#define BABIL_EI    3
#define BABIL_LEN   4
#define BABIL_EVTN  5
