#ifdef CC7700
#include "def-cc77.h"
#endif

#ifdef K2915
#include "def-k2915.h"
#endif

#ifdef SBS620
#include "def-sbs620.h"
#endif

#ifdef ADVME
#include "def-advme.h"
#endif

#ifdef V2718
#include "def-v2718.h"
#endif

#ifdef CCNET
#include "def-ccnet.h"
#endif

#ifdef CAMAC
#include "bb-camac.h"
#endif

#ifdef VME
#include "bb-vme.h"
#endif

