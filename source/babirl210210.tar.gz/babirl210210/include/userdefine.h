/* include/userdefine.h */

//#define BABIRLDIR "/home/baba/babirl"
//#define PIDDIR    "/home/baba/babirl/run"
