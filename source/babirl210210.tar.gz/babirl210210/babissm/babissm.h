/* babirl/babissm/babissm.h
 *
 * last modified : 07/03/07 19:24:26 
 *
 * Hidetada Baba
 * baba@ribf.riken.jp
 *
 */



int comfd;
char combuff[EB_BUFF_SIZE];
struct stssminfo ssminfo;
