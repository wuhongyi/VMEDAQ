#include <QCoreApplication>
#include <QTimer>
#include <QDebug>

#include <iostream>

#include "histomapping.h"

QTEST_MAIN(HistoMapping)

